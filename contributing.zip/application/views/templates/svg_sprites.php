<div style="display: none">
	<!-- svg sprite-->
	<svg style="width:0; height:0; visibility:hidden;" xmlns="http://www.w3.org/2000/svg">
	  <symbol id="icon_ion-icon-apps" viewBox="0 0 512 512">
	    <path d="M96 176h80V96H96v80zm120 240h80v-80h-80v80zm-120 0h80v-80H96v80zm0-120h80v-80H96v80zm120 0h80v-80h-80v80zM336 96v80h80V96h-80zm-120 80h80V96h-80v80zm120 120h80v-80h-80v80zm0 120h80v-80h-80v80z"/>
	  </symbol>
	</svg>
</div>
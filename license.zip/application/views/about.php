<div class="heading-default heading-default heading-default_context_default" style="background-image: url(<?= base_url()?>assets/img/banner-about.jpg); background-repeat: no-repeat; background-size: 100%;">
  <div class="container">
	<div class="heading-default__title">About Us</div>
	<ul class="heading-default__breadcrumbs">
	  <li class="heading-default__breadcrumb-item">
		<a class="heading-default__breadcrumb-link" href="#">Home</a>
	  </li>
	  <li class="heading-default__breadcrumb-item">About</li>
	</ul>
	<br>  
  </div>
</div>  
<div class="single-post">
  <div class="container">
    <div class="single-post__images row">
	  <div class="col-12" align="center">
		  <div class="col-4">
			<img style="border-radius: 17px;" alt="" class="single-post__image img-thumbnail" src="<?= base_url()?>assets/gallery/about.jpeg"/>
		  </div>
		  <p style="color: #fff"><b>Andi Priatna Chaniago</b><br>Ketua Umum IKLA kota Batam</p>
	  </div>
	</div>
	<div class="row">
      <div class="col-12 col-lg-8 offset-lg-2">
        <div class="single-post__text">
          <p align="justify">السَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ وَبَرَكَاتُة<br><br>
				  Puji syukur kami panjatkan kehadirat ALLAH SWT atas limpahan rahmat dan karunia-Nya sehingga Ikatan Keluarga Luhak AGAM & Bukittinggi ( IKLA BATAM ) berhasil membangun sebuah wadah informasi melalui website <a href="https://iklabatam.com"><b>www.iklabatam.com</b></a> Kehadiran webside IKLA BATAM diharapkan dapat memudahkan penyampaian informasi secara luas kepada *warga luhak agam dan bukitting di batam khususnya * serta sanak saudara kita di kampung halaman serta instansi pemerintah yang membutuhkan sebagai database update.<br><br>
				  Semoga dengan kehadiran Website ini harapannya akan terjalin informasi, komunikasi antar warga khususnya sebagai salah satu upaya kita mendapatkan informasi tetang keberadaan dan jumlah wqrga IKLA yg dirantau khususnya kota BATAM  serta mengatahui potensi dan kegiatan masing masing warga yang nantinya bisa disinergikan bersama sehingga dapat memajukan perekonomian warga IKLA dikota Batam khususnya dan warga Batam umumnya.<br><br>
				  Kesiapan dari semua warga IKLA sangat besar artinya bagi keberadaan website ini, sebab tanpa kesiapan dan peran serta aktif dari seluruh warga IKLA maka keberadaan website ini akan tidak ada gunanya.<br><br>
				  Sehubungan dengan hal tersebut maka semua warga IKLA harus mau untuk belajar menggunakan komputer dan internet, agar dapat meng-akses segala informasi yang berhubungan dengan IKLA batam.<br><br>
				  Demikian harapannya kami sampaikan dan terima kasih.<br><br>
				  و السلام عليكم  ورحمةالله و بركاتة</p>
        </div>
      </div>
    </div>
  </div>
</div>
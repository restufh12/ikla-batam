<div class="heading-default heading-default heading-default_context_default" style="background-image: url(<?= base_url()?>assets/img/home-banner5.jpg)">
  <div class="container">
    <div class="heading-default__title">Update Profile</div>
    <ul class="heading-default__breadcrumbs">
	  <li class="heading-default__breadcrumb-item">
		<a class="heading-default__breadcrumb-link" href="#">Home</a>
	  </li>
	  <li class="heading-default__breadcrumb-item">Account</li>
	  <li class="heading-default__breadcrumb-item">Profile</li>
	</ul>
    <br>  
  </div>
</div>  
<div class="contact-block">
  <div class="container">
    <div class="row">
      <div class="col-12 col-lg-12">
        <form class="contact-block__form">
          <div class="row">
            <div class="col-12 col-sm-2">
		          <label><br>Nama & Gelar Pusako</label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br>:</label>	
            </div>  
            <div class="col-12 col-sm-9">
              <input class="contact-block__input-text" placeholder="" type="text"/>
            </div>
		        <div class="col-12 col-sm-2">
		          <label><br>Jenis Kelamin</label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br>:</label>	
            </div>  
            <div class="col-12 col-sm-9">
              <input class="contact-block__input-text" placeholder="" type="text"/>
            </div> 
		        <div class="col-12 col-sm-2">
		          <label><br>Alamat Rumah</label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br>:</label>	
            </div>  
            <div class="col-12 col-sm-9">
              <input class="contact-block__input-text" placeholder="" type="text"/>
            </div>
		        <div class="col-12 col-sm-2">
		          <label><br>Pekerjaan</label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br>:</label>	
            </div>  
            <div class="col-12 col-sm-9">
              <input class="contact-block__input-text" placeholder="" type="text"/>
            </div>  
		        <div class="col-12 col-sm-2">
		          <label><br>Alamat Pekerjaan</label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br>:</label>	
            </div>  
            <div class="col-12 col-sm-9">
              <input class="contact-block__input-text" placeholder="" type="text"/>
            </div>
		        <div class="col-12 col-sm-2">
		          <label><br>Suku / Niniak Mamak</label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br>:</label>	
            </div>  
            <div class="col-12 col-sm-9">
              <input class="contact-block__input-text" placeholder="" type="text"/>
            </div>
		        <div class="col-12 col-sm-2">
		          <label><br>No. Hp / WA</label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br>:</label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br>+62</label>	
            </div>  
            <div class="col-12 col-sm-8">
              <input class="contact-block__input-text" placeholder="" type="text"/>
            </div>
		        <div class="col-12 col-sm-2">
		          <label><br>Email</label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br>:</label>	
            </div>
		        <div class="col-12 col-sm-9">
              <input class="contact-block__input-text" placeholder="" type="text"/>
            </div>  
		        <div class="col-12 col-sm-2">
		          <label><br>Asal Nagari</label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br>:</label>	
            </div>  
            <div class="col-12 col-sm-9">
              <input class="contact-block__input-text" placeholder="" type="text"/>
            </div>
		        <div class="col-12 col-sm-2">
		          <label><br>Golongan Darah</label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br>:</label>	
            </div>  
            <div class="col-12 col-sm-9">
              <input class="contact-block__input-text" placeholder="" type="text"/>
            </div>  
		        <div class="col-12 col-sm-2">
		          <label><br>Pendidikan</label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br>:</label>	
            </div>  
            <div class="col-12 col-sm-9">
              <input class="contact-block__input-text" placeholder="" type="text"/>
            </div>
		        <div class="col-12 col-sm-2">
		          <label><br>Hobi</label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br>:</label>	
            </div>  
            <div class="col-12 col-sm-9">
              <input class="contact-block__input-text" placeholder="" type="text"/>
            </div>
		        <div class="col-12 col-sm-2">
		          <label><br>Nama Istri</label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br>:</label>	
            </div>  
            <div class="col-12 col-sm-9">
              <input class="contact-block__input-text" placeholder="" type="text"/>
            </div>
		        <div class="col-12 col-sm-2">
		          <label><br>Nama Anak</label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br>:</label>	
            </div>  
            <div class="col-12 col-sm-4">
              <input class="contact-block__input-text" placeholder="Anak 1" type="text"/>
            </div>
		        <div class="col-12 col-sm-5">
              <input class="contact-block__input-text" placeholder="Anak 2" type="text"/>
            </div>
		        <div class="col-12 col-sm-2">
		          <label><br></label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br></label>	
            </div>  
            <div class="col-12 col-sm-4">
              <input class="contact-block__input-text" placeholder="Anak 3" type="text"/>
            </div>
		        <div class="col-12 col-sm-5">
              <input class="contact-block__input-text" placeholder="Anak 4" type="text"/>
            </div>
		        <div class="col-12 col-sm-2">
		          <label><br></label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br></label>	
            </div>  
            <div class="col-12 col-sm-4">
              <input class="contact-block__input-text" placeholder="Anak 5" type="text"/>
            </div>
		        <div class="col-12 col-sm-5">
              <input class="contact-block__input-text" placeholder="Anak 6" type="text"/>
            </div> 
		        <div class="col-12 col-sm-2">
		          <label><br>Upload Foto</label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br>:</label>	
            </div>  
            <div class="col-12 col-sm-9">
              <input class="contact-block__input-text" placeholder="" type="text"/>
            </div>
		        <div class="col-12 col-sm-2">
		          <label><br>Username</label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br>:</label>	
            </div>
		        <div class="col-12 col-sm-1">
		          <label><br>+62</label>	
            </div>  
            <div class="col-12 col-sm-8">
              <input class="contact-block__input-text" placeholder="Gunakan Nomor Hp / WA" type="text"/>
            </div>  
		        <div class="col-12 col-sm-2">
		          <label><br>Password</label>	
            </div>
    				<div class="col-12 col-sm-1">
    				  <label><br>:</label>	
            </div>  
            <div class="col-12 col-sm-9">
              <input class="contact-block__input-text" placeholder="" type="text"/>
            </div>    
		        <div class="col-12">
              <button class="contact-block__submit">Update
                <span class="contact-block__submit-icon icofont-caret-right"></span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>